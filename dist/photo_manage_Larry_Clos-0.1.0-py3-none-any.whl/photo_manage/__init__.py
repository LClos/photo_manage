"""Code package for managing photo files."""
